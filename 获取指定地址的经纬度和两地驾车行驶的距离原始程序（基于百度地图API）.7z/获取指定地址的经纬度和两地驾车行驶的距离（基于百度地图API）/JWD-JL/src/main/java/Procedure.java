import service.Getcoordinate;
import entity.*;
import service.Getdistance;

import java.util.Scanner;

//主函数
public class Procedure {
    //百度地图API的AK密钥
    private static final String AK = "0xWDlGYCwMagLNsCRqNDCPwK4tevca9l";

    public static void main(String[] args) throws Exception {

        System.out.println("请选择要使用的功能：\n"+"1、计算地址的经纬度\n"+"2、计算两地的距离");
        Scanner sc = new Scanner(System.in);
        while (true){
            int a = sc.nextInt();
            switch (a){
                case 1:
                    System.out.print("请输入要查询的地址：");
                    String addr = sc.next();

                    Address address = new Address();
                    address.setAddress(addr);


                    String coordinate1 = useCoordinate_baidu(address);
                    System.out.println(addr+"(纬度，经度):"+coordinate1);
                    System.exit(0);    //终止程序运行
                    break;
                case 2:
                    System.out.print("请输入出发地点：");
                    String start_address = sc.next();
                    System.out.print("请输入到达地点：");
                    String end_address = sc.next();


                    double distance = useDisance_baidu(start_address, end_address);
                    System.out.println(start_address+"到"+end_address+"的距离："+distance+"米");
                    System.exit(0); //终止程序运行
                    break;
                default:
                    System.out.println("请输入正确的功能键！！！");
            }
            continue;
        }



    }

    public static String useCoordinate_baidu(Address address) throws Exception {
        Getcoordinate gc = new Getcoordinate();
        Coordinate baidu = gc.getcoordinate_bybaidu(address,AK);
        //System.out.println(baidu);
        String coordinate = baidu.getLat()+","+baidu.getLng();
        return  coordinate;
    }

    public static double useDisance_baidu(String  start_address,String end_address) throws Exception {
        Address origin_address = new Address();
        Address destination_address = new Address();
        origin_address.setAddress(start_address);
        destination_address.setAddress(end_address);

        String origin = useCoordinate_baidu(origin_address);
        String destination = useCoordinate_baidu(destination_address);


        Getdistance gd = new Getdistance();
        double distance = gd.getdistance_bybaidu(origin, destination, AK);

        return distance;
    }

}
