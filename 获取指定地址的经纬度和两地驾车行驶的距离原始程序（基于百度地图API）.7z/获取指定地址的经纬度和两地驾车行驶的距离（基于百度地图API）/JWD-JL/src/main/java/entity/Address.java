package entity;

//地址的实体类——Address
public class Address {
    private String address;   //地址信息的字符串

    //Get方法
    public String getAddress() {
        return address;
    }

    //Set方法
    public void setAddress(String address) {
        this.address = address;
    }
}
