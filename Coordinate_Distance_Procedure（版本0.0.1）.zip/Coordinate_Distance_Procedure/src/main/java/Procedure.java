
import mianban.frame;

//主函数
public class Procedure {
    //百度地图API的AK密钥

    public static void main(String[] args) {

        /*
         *面板
         */
        new frame();

    }

}
