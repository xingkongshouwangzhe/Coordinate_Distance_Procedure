import entity.Address;
import entity.Distance_car;
import mianban.frame;
import util.FileUtil;
import util.Use_disance;

import java.util.List;

//主函数
public class Procedure {
    //百度地图API的AK密钥
    private static final String AK = "0xWDlGYCwMagLNsCRqNDCPwK4tevca9l";

    public static void main(String[] args) throws Exception {

        /*
        *面板
         */
        new frame();

//        Use_disance ud = new Use_disance();
//        String a= "清华大学";
//        String b = "北京大学";
//        String key = AK;
//        Distance_car car;
//
//        Address start = new Address();
//        Address end = new Address();
//        start.setAddress(a);
//        end.setAddress(b);
//
//        car = ud.use_disance_baidu(start,end,key);

//        FileUtil fileUtil = new FileUtil();
//        String a = "E:\\dizhi_jingweidu\\juli.txt";
//
//        List<String> addressList = fileUtil.txtToList(a);
//        for (String addr:addressList) {
//            System.out.println("ass:"+addr);
//
//            Address address_start = new Address();
//            Address address_end = new Address();
//
//            String[] addr_1 = addr.split("，");
//            address_start.setAddress(addr_1[0]);
//            address_end.setAddress(addr_1[1]);
//            System.out.println(addr_1[0]+"  "+addr_1[1]);
//            System.out.println(address_start.getAddress() +"\n"+ address_end.getAddress());
//
//        }


    }

}
